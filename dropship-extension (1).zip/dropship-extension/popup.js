// popup.js — Dropship Tracker v4 (with Potential Products)

// ─── FEES & FORMULA ──────────────────────────────────────────────────────────
const ALI_SHIPPING = 1.99;
const ALI_EXTRA    = 0.80;

function calcProfit(ebayPrice, aliItemPrice) {
  const yourCost  = aliItemPrice + ALI_SHIPPING + ALI_EXTRA;
  const fee_fixed = 0.35;
  const fee_15    = yourCost * 0.15;
  const fee_12    = ebayPrice * 0.12;
  const fee_low   = ebayPrice < 10 ? 1.99 : 0;
  const profit    = ebayPrice - yourCost - fee_fixed - fee_15 - fee_12 - fee_low;
  const profitPct = (profit / ebayPrice) * 100;
  return {
    profit:    +profit.toFixed(2),
    profitPct: +profitPct.toFixed(1),
    yourCost:  +yourCost.toFixed(2),
    fee_fixed,
    fee_15:    +fee_15.toFixed(2),
    fee_12:    +fee_12.toFixed(2),
    fee_low,
  };
}

function profitStatus(pct) {
  if (pct >= 20) return 'good';
  if (pct >= 5)  return 'low';
  return 'loss';
}

function suggestedPrice(totalCost) {
  const raw     = (totalCost + 0.35 + totalCost * 0.15) / (1 - 0.12 - 0.30);
  const rounded = Math.ceil(raw - 0.01) + 0.99;
  return rounded < raw ? rounded + 1 : rounded;
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const container = () => $('content');

function daysAgo(iso) {
  if (!iso) return '?';
  const d = Math.floor((Date.now() - new Date(iso)) / 86400000);
  if (d === 0) return 'today';
  if (d === 1) return 'yesterday';
  return `${d} days ago`;
}

function fmt(n) { return '$' + Math.abs(n).toFixed(2); }

function makePairId(ebayId, aliId, aliPrice, varLabel) {
  const cents = Math.round(parseFloat(aliPrice) * 100);
  let id = `${ebayId}_${aliId}_v${cents}`;
  if (varLabel && varLabel.trim()) {
    const slug = varLabel.trim().toLowerCase().replace(/[^a-z0-9]+/g, '_').slice(0, 20);
    id += `_${slug}`;
  }
  return id;
}

// ─── STATE ───────────────────────────────────────────────────────────────────
let session = { ebayPrice: null, ebayTitle: null, ebayUrl: null, ebayItemId: null };

function loadSession(cb) {
  chrome.storage.local.get(['session'], r => {
    if (r.session) session = { ...session, ...r.session };
    cb();
  });
}
function saveSession() { chrome.storage.local.set({ session }); }

function getProducts(cb) {
  chrome.storage.local.get(['products', 'pairs', 'potentialPairs'], r =>
    cb(r.products || {}, r.pairs || {}, r.potentialPairs || {})
  );
}
function saveProducts(products, pairs, potentialPairs, cb) {
  chrome.storage.local.set({ products, pairs, potentialPairs }, cb);
}

// ─── INIT ─────────────────────────────────────────────────────────────────────
function isAliUrl(url) { return /aliexpress\.(com|us)\/(item|i)\//.test(url); }
function isEbayUrl(url) { return /ebay\.com\/itm\//.test(url); }

loadSession(() => {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const url = tabs[0]?.url || '';
    if      (isEbayUrl(url)) renderEbayView(tabs[0].id);
    else if (isAliUrl(url))  renderAliView(tabs[0].id);
    else                     renderOtherView();
  });
});

$('resetBtn').addEventListener('click', () => {
  session = { ebayPrice: null, ebayTitle: null, ebayUrl: null, ebayItemId: null };
  saveSession();
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const url = tabs[0]?.url || '';
    if      (isEbayUrl(url)) renderEbayView(tabs[0].id);
    else if (isAliUrl(url))  renderAliView(tabs[0].id);
    else                     renderOtherView();
  });
});

// ─── CSV DROPDOWN ─────────────────────────────────────────────────────────────
$('exportBtn').addEventListener('click', (e) => {
  e.stopPropagation();
  const existing = document.querySelector('.csv-dropdown');
  if (existing) { existing.remove(); return; }

  const dropdown = document.createElement('div');
  dropdown.className = 'csv-dropdown';
  dropdown.innerHTML = `
    <button id="exportListedBtn">📦 Export Listed CSV</button>
    <button id="exportPotentialBtn">⭐ Export Potential CSV</button>
  `;
  document.querySelector('.header-actions').appendChild(dropdown);

  dropdown.querySelector('#exportListedBtn').addEventListener('click', () => {
    exportCSV('listed');
    dropdown.remove();
  });
  dropdown.querySelector('#exportPotentialBtn').addEventListener('click', () => {
    exportCSV('potential');
    dropdown.remove();
  });

  setTimeout(() => {
    document.addEventListener('click', () => dropdown.remove(), { once: true });
  }, 50);
});

// ─── EBAY VIEW ────────────────────────────────────────────────────────────────
function renderEbayView(tabId) {
  chrome.tabs.sendMessage(tabId, { action: 'GET_EBAY_DATA' }, res => {
    const livePrice = res?.price  || null;
    const liveTitle = res?.title  || null;
    const liveUrl   = res?.url    || null;
    const liveId    = res?.itemId || null;

    const price = livePrice || null;
    const title = liveTitle || 'eBay Listing';
    const ebayDone = !!session.ebayPrice;

    let priceBlock = '';
    if (price) {
      priceBlock = `
        <div class="price-row">
          <span class="price-num">$${price.toFixed(2)}</span>
        </div>
        <div class="site-badge">🛒 <span>${title}</span></div>
        <div class="ai-note">💬 Found your eBay price. If this listing has <strong>variations</strong> (Single / Set of 3 / etc.), select the specific one you're sourcing on eBay before saving.</div>
      `;
    } else {
      priceBlock = `
        <div class="status-msg"><div class="pulse"></div>Reading the page…</div>
        <div class="ai-note">💬 Couldn't read the price automatically. Enter it manually below.</div>
      `;
    }

    container().innerHTML = `
      <div class="step ${ebayDone ? 'done' : 'active'}">
        <div class="step-header">
          <div class="step-num">${ebayDone ? '✓' : '1'}</div>
          <div class="step-label">eBay Price ${ebayDone ? '— Saved' : '— This Page'}</div>
        </div>
        ${ebayDone ? `
          <div class="price-num" style="font-size:22px;">$${session.ebayPrice.toFixed(2)}</div>
          <div class="site-badge">🛒 <span>${session.ebayTitle}</span></div>
          <div class="ai-note">💬 Got it! Now open the AliExpress source and I'll calculate your profit.</div>
          <button class="scan-btn outline" id="rescanBtn">↺ Re-scan this page</button>
        ` : `
          ${priceBlock}
          ${price ? `<button class="scan-btn" id="saveEbayBtn">💾 Save eBay Price & Go to Ali</button>` : `
            <div class="manual-hint">Can't read price? Enter manually:</div>
            <div class="manual-row">
              <input class="manual-input" id="manualEbay" type="number" step="0.01" min="0" placeholder="e.g. 12.99" />
              <button class="set-btn" id="setManualBtn">Save</button>
            </div>
          `}
        `}
      </div>
      ${ebayDone ? `<div class="next-hint">⬇️ Open the AliExpress source and click this extension there — I'll handle the rest.</div>` : ''}
    `;

    $('saveEbayBtn')?.addEventListener('click', () => {
      session.ebayPrice = price; session.ebayTitle = title;
      session.ebayUrl = liveUrl; session.ebayItemId = liveId;
      saveSession(); renderEbayView(tabId);
    });
    $('rescanBtn')?.addEventListener('click', () => {
      session.ebayPrice = livePrice; session.ebayTitle = liveTitle;
      session.ebayUrl = liveUrl; session.ebayItemId = liveId;
      saveSession(); renderEbayView(tabId);
    });
    $('setManualBtn')?.addEventListener('click', () => {
      const val = parseFloat($('manualEbay').value);
      if (!isNaN(val) && val > 0) {
        session.ebayPrice = val; session.ebayTitle = title || 'eBay Listing';
        session.ebayUrl = liveUrl; session.ebayItemId = liveId;
        saveSession(); renderEbayView(tabId);
      }
    });
  });
}

// ─── ALIEXPRESS VIEW ──────────────────────────────────────────────────────────
function renderAliView(tabId) {
  if (!session.ebayPrice) {
    container().innerHTML = `
      <div class="warning">
        <div class="w-icon">⚠️</div>
        <div>No eBay price saved yet.<br/>Go to your eBay listing first and click this extension there.</div>
      </div>
      <div class="manual-hint" style="margin-top:10px;">Or enter eBay price manually:</div>
      <div class="manual-row">
        <input class="manual-input" id="manualEbay2" type="number" step="0.01" min="0" placeholder="eBay price e.g. 12.99" />
        <button class="set-btn" id="setEbay2">Save</button>
      </div>
    `;
    $('setEbay2')?.addEventListener('click', () => {
      const val = parseFloat($('manualEbay2').value);
      if (!isNaN(val) && val > 0) {
        session.ebayPrice = val;
        session.ebayTitle = 'eBay (manual)';
        session.ebayUrl   = null;
        session.ebayItemId = 'manual_' + Date.now();
        saveSession();
        renderAliView(tabId);
      }
    });
    return;
  }

  chrome.tabs.sendMessage(tabId, { action: 'GET_ALI_DATA' }, res => {
    const scannedPrice = res?.price || null;
    const aliTitle     = res?.title || 'AliExpress Product';
    const liveUrl      = res?.url   || window.location.href;
    const aliId        = res?.itemId || ('ali_' + Date.now());

    // Load stored history for this Ali item to detect price changes
    chrome.storage.local.get(['products'], storageData => {
      const storedAli = storageData.products?.['ali_' + aliId] || null;
      const prevPrice = storedAli?.previousPrice || null;
      const lastSeen  = storedAli?.lastSeenDate  || null;
      const history   = storedAli?.history        || [];

    function render(aliPrice, varLabel) {
      const ep = session.ebayPrice;
      const ap = aliPrice;

      // ── PRICE CHANGE BANNER ─────────────────────────────────────────────────
      let priceChangeBanner = '';
      if (ap != null && lastSeen) {
        const diff = prevPrice != null ? ap - prevPrice : 0;
        const priceChanged = prevPrice != null && Math.abs(diff) > 0.001;

        // Format lastSeen as "9:21 AM · 10 March, 2026"
        function fmtDateTime(iso) {
          if (!iso) return '?';
          const d = new Date(iso);
          let h = d.getHours(), m = d.getMinutes();
          const ampm = h >= 12 ? 'PM' : 'AM';
          h = h % 12 || 12;
          const mm = String(m).padStart(2, '0');
          const day = d.getDate();
          const month = d.toLocaleDateString('en-US', { month: 'long' });
          const year = d.getFullYear();
          return `${h}:${mm} ${ampm} · ${day} ${month}, ${year}`;
        }

        if (priceChanged) {
          const diffFmt = (diff > 0 ? '+' : '') + '$' + Math.abs(diff).toFixed(2);
          const isUp    = diff > 0;
          const color   = isUp ? 'var(--red)' : 'var(--green)';
          const bgColor = isUp ? '#1a0808' : '#081a0e';
          const border  = isUp ? '#4a1515' : '#154a2a';
          const arrow   = isUp ? '⬆' : '⬇';
          const msg     = isUp
            ? `Price went <strong style="color:var(--red)">UP ${diffFmt}</strong> — was <strong>$${prevPrice.toFixed(2)}</strong>, now <strong>$${ap.toFixed(2)}</strong>. Consider raising your eBay price.`
            : `Price went <strong style="color:var(--green)">DOWN ${diffFmt}</strong> — was <strong>$${prevPrice.toFixed(2)}</strong>, now <strong>$${ap.toFixed(2)}</strong>. Your margin improved!`;

          let historyLine = '';
          if (history.length > 1) {
            const recent = history.slice(-4).reverse();
            historyLine = `<div style="margin-top:5px;font-size:10px;color:#71717a;font-family:'Space Mono',monospace;line-height:1.8;">
              ${recent.map((h, i) => `<span style="color:${i===0?color:'#71717a'}">${i===0?'● ':'○ '}$${parseFloat(h.price).toFixed(2)} <span style="opacity:.5">${h.date ? h.date.split('T')[0] : ''}</span></span>`).join('  ')}
            </div>`;
          }

          priceChangeBanner = `
            <div style="background:${bgColor};border:1px solid ${border};border-radius:9px;padding:10px 12px;font-size:11.5px;line-height:1.6;">
              <div style="font-weight:700;font-size:12px;color:${color};margin-bottom:3px;">${arrow} Ali Price Changed!</div>
              <div style="color:var(--text);">${msg}</div>
              <div style="margin-top:4px;font-size:10.5px;color:#71717a;">Last checked: ${fmtDateTime(lastSeen)}</div>
              ${historyLine}
            </div>
          `;
        } else {
          // Same price — show "last verified" message
          priceChangeBanner = `
            <div style="background:#0d1a0d;border:1px solid #1e3a1e;border-radius:9px;padding:9px 12px;font-size:11.5px;display:flex;align-items:center;gap:8px;">
              <span style="font-size:14px;">✅</span>
              <div>
                <span style="color:var(--green);font-weight:600;">Same price as last check</span>
                <div style="font-size:10.5px;color:#71717a;margin-top:1px;">Last verified: ${fmtDateTime(lastSeen)}</div>
              </div>
            </div>
          `;
        }
      }

      let resultHtml = '';
      if (ap != null && ep != null) {
        const r      = calcProfit(ep, ap);
        const status = profitStatus(r.profitPct);
        const statusLabel = status === 'good' ? '🟢 GOOD MARGIN' : status === 'low' ? '🟡 LOW MARGIN' : '🔴 LOSING MONEY';
        const statusClass = status === 'good' ? 'good' : status === 'low' ? 'low' : 'loss';
        const sugg = suggestedPrice(r.yourCost);

        resultHtml = `
          <div class="result-card ${statusClass}">
            <div class="result-status">${statusLabel}</div>
            <div class="result-profit" style="color:${status==='good'?'var(--green)':status==='low'?'var(--amber)':'var(--red)'}">
              ${r.profit >= 0 ? '+' : '-'}${fmt(r.profit)}
              <span class="result-pct">(${r.profitPct >= 0 ? '+' : ''}${r.profitPct}%)</span>
            </div>
            <div class="breakdown">
              <div class="br-row"><span>eBay Sale Price</span><span class="br-val">$${ep.toFixed(2)}</span></div>
              <div class="br-row"><span>Ali Item Price</span><span class="br-val neg">−${fmt(ap)}</span></div>
              <div class="br-row"><span>Ali Shipping</span><span class="br-val neg">−${fmt(ALI_SHIPPING)}</span></div>
              <div class="br-row"><span>Ali Extra</span><span class="br-val neg">−${fmt(ALI_EXTRA)}</span></div>
              <div class="br-sep"></div>
              <div class="br-row"><span>Fixed eBay Fee</span><span class="br-val neg">−$0.35</span></div>
              <div class="br-row"><span>15% of Your Cost</span><span class="br-val neg">−${fmt(r.fee_15)}</span></div>
              <div class="br-row"><span>12% eBay Final Value</span><span class="br-val neg">−${fmt(r.fee_12)}</span></div>
              ${ep < 10 ? `<div class="br-row"><span>Low Value Fee</span><span class="br-val neg">−$1.99</span></div>` : ''}
              <div class="br-total"><span>Net Profit</span><span style="color:${status==='good'?'var(--green)':status==='low'?'var(--amber)':'var(--red)'}">${r.profit>=0?'+':'-'}${fmt(r.profit)}</span></div>
            </div>
          </div>
          ${status !== 'good' ? `<div class="cost-note">💡 To hit 30% margin, price at: <strong>$${sugg.toFixed(2)}</strong></div>` : ''}

          <div style="display:flex;gap:6px;margin-top:2px;">
            <button class="scan-btn" id="savePairBtn" style="flex:1">💾 Save This Pair</button>
            <button class="scan-btn" id="savePotentialBtn" style="flex:1;background:transparent;color:#a78bfa;border:1px solid #a78bfa;">⭐ Save as Potential</button>
          </div>
        `;
      }

      container().innerHTML = `
        <div class="step done">
          <div class="step-header">
            <div class="step-num">✓</div>
            <div class="step-label">eBay — Saved</div>
          </div>
          <div class="price-num" style="font-size:18px;">$${ep.toFixed(2)}</div>
          <div class="site-badge">🛒 <span>${session.ebayTitle}</span></div>
        </div>

        ${priceChangeBanner}

        <div class="step active">
          <div class="step-header">
            <div class="step-num">2</div>
            <div class="step-label">AliExpress — Scanned ✓</div>
          </div>
          <div class="price-row">
            <span class="price-num">$${ap != null ? ap.toFixed(2) : '?'}</span>
          </div>
          <div class="site-badge">📦 <span>${aliTitle}</span></div>
          ${ap != null ? `<div class="cost-note">+ $${ALI_SHIPPING} shipping + $${ALI_EXTRA} extra = Your Cost: <strong>$${(ap + ALI_SHIPPING + ALI_EXTRA).toFixed(2)}</strong></div>` : ''}

          <div class="manual-hint">💬 Variation label (e.g. "30-40g 1Pc")</div>
          <input class="manual-input" id="varLabelInput" type="text" placeholder="optional" value="${varLabel||''}" style="margin-top:4px;width:100%;"/>

          ${ap != null ? `
            <div class="manual-hint" style="margin-top:8px;">💬 Override price for this variation:</div>
            <div class="manual-row">
              <input class="manual-input" id="overridePrice" type="number" step="0.01" min="0" placeholder="${ap.toFixed(2)}" />
              <button class="set-btn" id="recalcBtn">Recalc</button>
            </div>
          ` : `
            <div class="manual-hint" style="margin-top:8px;">Enter price manually:</div>
            <div class="manual-row">
              <input class="manual-input" id="overridePrice" type="number" step="0.01" min="0" placeholder="e.g. 3.80" />
              <button class="set-btn" id="recalcBtn">Recalc</button>
            </div>
          `}
        </div>

        ${resultHtml}
      `;

      $('recalcBtn')?.addEventListener('click', () => {
        const override = parseFloat($('overridePrice').value);
        const newLabel = $('varLabelInput')?.value || '';
        render(isNaN(override) ? scannedPrice : override, newLabel);
      });

      $('varLabelInput')?.addEventListener('input', () => {
        // live re-render label but don't recalc price
      });

      function doSave(type) {
        const finalAliPrice = (() => {
          const ov = parseFloat($('overridePrice')?.value);
          return !isNaN(ov) && ov > 0 ? ov : scannedPrice;
        })();
        const varLabel = $('varLabelInput')?.value?.trim() || '';

        if (!finalAliPrice) { showToast('⚠️ No Ali price found — enter manually'); return; }

        const now    = new Date().toISOString();
        const ebayId = session.ebayItemId || ('manual_' + Date.now());
        const pairId = makePairId(ebayId, aliId, finalAliPrice, varLabel);
        const ebayKey = `ebay_${ebayId}`;
        const aliKey  = `ali_${aliId}_v${Math.round(finalAliPrice * 100)}`;

        getProducts((products, pairs, potentialPairs) => {
          // Upsert eBay product
          if (!products[ebayKey]) {
            products[ebayKey] = {
              type: 'ebay', itemId: ebayId, url: session.ebayUrl || '',
              title: session.ebayTitle || 'eBay', currentPrice: session.ebayPrice,
              previousPrice: null, firstSeenDate: now, lastSeenDate: now,
              history: [{ price: session.ebayPrice, date: now }]
            };
          } else {
            products[ebayKey].currentPrice = session.ebayPrice;
            products[ebayKey].title = session.ebayTitle || products[ebayKey].title;
            products[ebayKey].lastSeenDate = now;
          }

          // Upsert Ali product
          if (!products[aliKey]) {
            products[aliKey] = {
              type: 'ali', itemId: aliId, url: liveUrl || '', title: aliTitle,
              currentPrice: finalAliPrice, previousPrice: null,
              variationLabel: varLabel,
              firstSeenDate: now, lastSeenDate: now,
              history: [{ price: finalAliPrice, date: now }]
            };
          } else {
            if (products[aliKey].currentPrice !== finalAliPrice) {
              products[aliKey].previousPrice = products[aliKey].currentPrice;
              products[aliKey].currentPrice  = finalAliPrice;
              products[aliKey].history = products[aliKey].history || [];
              products[aliKey].history.push({ price: finalAliPrice, date: now });
              if (products[aliKey].history.length > 10) products[aliKey].history.shift();
            }
            products[aliKey].lastSeenDate = now;
            if (varLabel) products[aliKey].variationLabel = varLabel;
          }

          if (type === 'listed') {
            pairs[pairId] = { ebayKey, aliKey, variationLabel: varLabel };
          } else {
            potentialPairs[pairId] = { ebayKey, aliKey, variationLabel: varLabel, savedDate: now.split('T')[0] };
          }

          saveProducts(products, pairs, potentialPairs, () => {
            updateStoredCSV(products, pairs, potentialPairs);
            const label = type === 'listed' ? '✅ Pair saved!' : '⭐ Saved as Potential!';
            showToast(label);
            session = { ebayPrice: null, ebayTitle: null, ebayUrl: null, ebayItemId: null };
            saveSession();
            const btn = type === 'listed' ? $('savePairBtn') : $('savePotentialBtn');
            if (btn) {
              btn.textContent = type === 'listed' ? '✅ Saved!' : '⭐ Saved!';
              btn.disabled = true;
              btn.style.background = type === 'listed' ? 'var(--green)' : '#7c3aed';
              btn.style.color = '#fff';
              btn.style.border = 'none';
            }
          });
        });
      }

      $('savePairBtn')?.addEventListener('click', () => doSave('listed'));
      $('savePotentialBtn')?.addEventListener('click', () => doSave('potential'));
    }

    render(scannedPrice, '');
    }); // end chrome.storage.local.get
  });
}

// ─── OTHER PAGE VIEW ─────────────────────────────────────────────────────────
function renderOtherView() {
  getProducts((products, pairs, potentialPairs) => {
    const pairCount      = Object.keys(pairs).length;
    const potentialCount = Object.keys(potentialPairs).length;
    let alerts = 0;
    for (const { aliKey } of Object.values(pairs)) {
      const ap = products[aliKey];
      if (ap?.previousPrice && ap.currentPrice > ap.previousPrice) alerts++;
    }

    container().innerHTML = `
      <div class="info-box">
        <div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:4px;">Navigate to a listing to get started</div>
        <div style="font-size:12px;color:var(--muted);">Open an <strong style="color:var(--text);">eBay listing</strong> or <strong style="color:var(--text);">AliExpress product</strong> and click this extension.</div>
      </div>

      ${session.ebayPrice ? `
        <div class="step done" style="padding:10px 14px;">
          <div class="step-header"><div class="step-num">✓</div><div class="step-label">eBay Saved</div></div>
          <div class="price-num" style="font-size:18px;">$${session.ebayPrice.toFixed(2)}</div>
          <div class="site-badge">🛒 <span>${session.ebayTitle}</span></div>
        </div>
      ` : ''}

      <div class="stats-row">
        <div class="stat"><span class="stat-n">${pairCount}</span><span class="stat-l">Listed Pairs</span></div>
        <div class="stat"><span class="stat-n" style="color:#a78bfa;">${potentialCount}</span><span class="stat-l">Potential</span></div>
        <div class="stat"><span class="stat-n" style="color:${alerts > 0 ? 'var(--red)' : 'var(--green)'};">${alerts}</span><span class="stat-l">Alerts</span></div>
      </div>
    `;
  });
}

// ─── PERSISTENT CSV ───────────────────────────────────────────────────────────
function buildCSVRows(products, pairs) {
  const headers = [
    'pair_id','variation_label','name',
    'ebay_url','ebay_price',
    'ali_url','ali_price',
    'total_cost','profit','profit_pct','status',
    'first_saved','ali_last_seen','ali_price_change'
  ];
  const rows = [headers.join(',')];

  for (const [pairId, { ebayKey, aliKey, variationLabel }] of Object.entries(pairs)) {
    const ep = products[ebayKey];
    const ap = products[aliKey];
    if (!ep) continue;

    const ebayPrice = parseFloat(ep.currentPrice);
    const aliPrice  = ap ? parseFloat(ap.currentPrice) : NaN;
    const varLabel  = variationLabel || ap?.variationLabel || '';
    let profit = '', profitPct = '', status = '', totalCost = '', aliChange = '';

    if (ap && !isNaN(ebayPrice) && !isNaN(aliPrice)) {
      const r = calcProfit(ebayPrice, aliPrice);
      profit    = r.profit.toFixed(2);
      profitPct = r.profitPct.toFixed(1);
      status    = profitStatus(r.profitPct);
      totalCost = r.yourCost.toFixed(2);
      const prev = parseFloat(ap.previousPrice);
      if (!isNaN(prev) && prev !== aliPrice) {
        const d = aliPrice - prev;
        aliChange = (d > 0 ? '+' : '') + d.toFixed(2);
      }
    }

    rows.push([
      pairId,
      `"${varLabel.replace(/"/g, '""')}"`,
      `"${(ep.title || '').replace(/"/g, '""')}"`,
      ep.url || '',
      !isNaN(ebayPrice) ? ebayPrice.toFixed(2) : '',
      ap ? (ap.url || '') : '',
      !isNaN(aliPrice)  ? aliPrice.toFixed(2)  : '',
      totalCost, profit, profitPct, status,
      ep.firstSeenDate ? ep.firstSeenDate.split('T')[0] : '',
      ap?.lastSeenDate  ? ap.lastSeenDate.split('T')[0]  : '',
      aliChange
    ].join(','));
  }

  return rows.join('\r\n');
}

function buildPotentialCSVRows(products, potentialPairs) {
  const headers = [
    'pair_id','variation_label','name',
    'ebay_url','ebay_price',
    'ali_url','ali_price',
    'total_cost','profit','profit_pct','status','saved_date'
  ];
  const rows = [headers.join(',')];

  for (const [pairId, { ebayKey, aliKey, variationLabel, savedDate }] of Object.entries(potentialPairs)) {
    const ep = products[ebayKey];
    const ap = products[aliKey];
    if (!ep) continue;

    const ebayPrice = parseFloat(ep.currentPrice);
    const aliPrice  = ap ? parseFloat(ap.currentPrice) : NaN;
    const varLabel  = variationLabel || ap?.variationLabel || '';
    let profit = '', profitPct = '', status = '', totalCost = '';

    if (ap && !isNaN(ebayPrice) && !isNaN(aliPrice)) {
      const r = calcProfit(ebayPrice, aliPrice);
      profit    = r.profit.toFixed(2);
      profitPct = r.profitPct.toFixed(1);
      status    = profitStatus(r.profitPct);
      totalCost = r.yourCost.toFixed(2);
    }

    rows.push([
      pairId,
      `"${varLabel.replace(/"/g, '""')}"`,
      `"${(ep.title || '').replace(/"/g, '""')}"`,
      ep.url || '',
      !isNaN(ebayPrice) ? ebayPrice.toFixed(2) : '',
      ap ? (ap.url || '') : '',
      !isNaN(aliPrice)  ? aliPrice.toFixed(2)  : '',
      totalCost, profit, profitPct, status,
      savedDate || ''
    ].join(','));
  }

  return rows.join('\r\n');
}

function updateStoredCSV(products, pairs, potentialPairs) {
  const csv          = '\uFEFF' + buildCSVRows(products, pairs);
  const potentialCsv = '\uFEFF' + buildPotentialCSVRows(products, potentialPairs);
  chrome.storage.local.set({ persistentCSV: csv, persistentPotentialCSV: potentialCsv });
}

// ─── EXPORT CSV ──────────────────────────────────────────────────────────────
function exportCSV(type = 'listed') {
  getProducts((products, pairs, potentialPairs) => {
    const isPotential = type === 'potential';
    const targetPairs = isPotential ? potentialPairs : pairs;
    const filename    = isPotential ? 'dropship_potential.csv' : 'dropship_products.csv';

    if (!Object.keys(targetPairs).length) {
      showToast(isPotential ? '💬 No potential pairs saved yet' : '💬 No pairs saved yet');
      return;
    }

    const csvContent = isPotential
      ? '\uFEFF' + buildPotentialCSVRows(products, potentialPairs)
      : '\uFEFF' + buildCSVRows(products, pairs);

    const blob    = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const blobUrl = URL.createObjectURL(blob);
    const count   = Object.keys(targetPairs).length;

    chrome.downloads.download({
      url: blobUrl,
      filename: filename,
      conflictAction: 'overwrite',
      saveAs: false
    }, () => {
      URL.revokeObjectURL(blobUrl);
      showToast(`✅ ${count} ${isPotential ? 'potential ' : ''}pairs → ${filename}`);
    });
  });
}

// ─── TOAST ───────────────────────────────────────────────────────────────────
function showToast(msg) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.classList.add('show'), 10);
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, 2500);
}